# icm

![Version: 4.0.0](https://img.shields.io/badge/Version-4.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 17.4](https://img.shields.io/badge/AppVersion-17.4-informational?style=flat-square)

Inspire Content Manager

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| image.name | string | `""` | Defines the URL address of the ICM image stored in a Docker image repository. |
| image.tag | string | `""` | Defines a specific version of the ICM image to be deployed. |
| image.pullPolicy | string | `"IfNotPresent"` | Defines the ICM image pull policy. [IfNotPresent/Always] |
| volumes | list | `[]` | Defines an array of volumes to be mounted to the ICM pod. For example, you may need to mount a Container Storage Interface (CSI) volume to pass Secrets to Kubernetes from an external secret management system (e.g. AWS Secrets Manager). |
| activateVolumes | object | `{"enabled":false,"volumes":[{"name":"my-csi-storage"}]}` | Creates an Init Container that will mount the given volumes to the application pod. It also instructs the CSI driver to create Kubernetes Secrets from Secrets stored in external storage (e.g. AWS Secrets Manager). It uses the 'SecretProviderClass' definition to manage the Secret synchronization. |
| activateVolumes.enabled | bool | `false` | Defines whether or not to create the Init Container. |
| activateVolumes.volumes | list | `[{"name":"my-csi-storage"}]` | Defines an array of volumes to be mounted. |
| db.host | string | `""` | Defines the hostname of the server that runs the database. |
| db.port | string | `""` | Defines the port of the server that runs the database. |
| db.user | string | `""` | Defines (in plain text) the username of the database user. Use the 'userSource' variable instead if you wish to define the username using a Secret. |
| db.userSource | object | `{"secretKey":"","secretName":"","useSecret":false}` | Available since the 15.0 GA version of ICM. Uses a Secret to define the username of the database user. |
| db.pass | string | `""` | Defines (in plain text) the password of the database user. Use the 'passSource' variable instead if you wish to define the password using a Secret. |
| db.passSource | object | `{"secretKey":"","secretName":"","useSecret":false}` | Available since the 15.0 GA version of ICM. Uses a Secret to define the password of the database user. |
| db.name | string | `""` | Defines the name of an existing database that will be used. |
| db.type | string | `""` | Defines the type of your database. [PostgreSql/Oracle/MsSql/MicrosoftSQL/SQLAzure/MySql/DB2] |
| db.connectionString | string | `""` | Defines (in plain text) a custom connection string to connect to the database. Use the 'connectionStringSource' variable instead if you wish to define the connection string using a Secret. |
| db.connectionStringSource | object | `{"secretKey":"","secretName":"","useSecret":false}` | Available since the 15.0 GA version of ICM. Uses a Secret or a Volume to define a custom connection string to connect to the database. |
| db.connectionStringAdd | string | `""` | Allows you to customize the database connection if you use the standard database connection settings (e.g. host, port etc.). |
| replicaCount | int | `1` | Defines the number of replicas to be created after deployment. |
| shutdownTimeout | int | `90` | Defines how long (in seconds) Kubernetes should wait before shutting down the pod. |
| useInitImport | bool | `false` | Defines whether you wish to import a package into ICM using a Kubernetes pattern for importing big data. Build a docker image containing the ICM package you wish to import. The container starts as an init container and its init script copies and renames the package to /opt/import/initialIcmData.pkg. |
| initImport.image.name | string | `""` | Defines the URL address of the ICM package image stored in a Docker image repository. |
| initImport.image.tag | string | `""` | Defines a specific version of the ICM package image to be deployed. |
| initImport.image.pullPolicy | string | `"IfNotPresent"` | Defines the ICM package image pull policy. [IfNotPresent/Always] |
| addParams | string | `""` | Defines ICM commands for running as an application. For example, the -allowdatarecording command is necessary for Scaler's data recording feature. |
| configFileContent | string | `""` | Defines a configuration to be created in the InspireICM.config file. For example: <AllowedDirectories></AllowedDirectories>. The ConnectionString method must be used along with configFileContent because a mounted file becomes readonly and ICM cannot write into it. |
| externalAccess.enabled | bool | `false` | Since the 15.0 version, this feature allows you to configure ICM to run an HTTPS server. Clients can connect to ICM using the HTTPS protocol. If you enable 'externalAccess', you must also configure the 'ingress' settings. |
| ingress.enabled | bool | `false` | Since the 15.0 version, this feature allows you to enable Ingress, a Kubernetes APi object, providing load balancing. |
| ingress.ingressClassName | string | `""` | Defines the name of the Ingress class to use. |
| ingress.host | string | `""` | Defines the Ingress host. |
| ingress.tls.enabled | bool | `true` | Enables HTTPS for ICM. TLS must be enabled for 'externalAccess' to work. |
| ingress.tls.secretName | string | `""` | The functionality of the 'secretName' parameter differs based on how you intend to provide a Kubernetes secret that stores the required certificate: 1) If you create a Kubernetes TLS secret that stores the required certificate manually by yourself, enter the name of the secret in the 'secretName' parameter.    To learn about Kubernetes TLS secrets, see Kubernetes documentation at https://kubernetes.io/docs/concepts/configuration/secret/#tls-secrets. 2) If you intend to use the 'clusterIssuer' parameter to provide the required certificate, use the 'secretName' parameter to define a custom name for a secret that will be created by the cluster issuer. |
| ingress.tls.clusterIssuer | string | `""` | Allows you to define the name of a cluster-issuer to be used for creating the certificate secret. For more information about cluster issuer setup, see one of the following documentations based on which platform you use to deploy Inspire: AKS (Application Gateway Kubernetes Ingress): https://azure.github.io/application-gateway-kubernetes-ingress/how-tos/lets-encrypt/#certificate-issuance-with-letsencryptorg EKS (NGINX Ingress): https://cert-manager.io/docs/tutorials/acme/ingress/ |
| ingress.customAnnotations | object | `{}` | Allows to define annotations which influence the Ingress Controller behavior. |
| useEveryStartupSettings | bool | `false` | Enables or disables the use of the onEveryStartupSettings object. |
| onEveryStartupSettings | object | `{"packageImportExport":{},"passwordAccountPolicy":{}}` | An object whose structure is the same as the structure of the initialServerSettings object. The object's settings are applied every time ICM starts. |
| useInitialServerSettings | bool | `true` | Enables or disables the use of the initialServerSettings object. |
| initialServerSettings | object | `{"packageImportExport":{"overwriteExistingUsersOnImport":false},"passwordAccountPolicy":{}}` | An object whose settings are applied only once when ICM is initialized. The content of this object is transformed to JSON format and passed directly to ICM. Uncomment and configure the packageImportExport and passwordAccountPolicy settings. To learn about the settings' purpose see the Password and Account Policy Tab sections of Inspire Designer User Manual. |
| role | string | `"icm"` | Internal parameter |
| livenessProbe | object | `{"failureThreshold":10,"initialDelaySeconds":5,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":2}` | Learn about liveness probes at https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/. Learn about the probe's configuration settings at https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/#configure-probes. |
| livenessProbe.initialDelaySeconds | int | `5` | Defines the delay before the ICM container liveness probe is initiated. |
| livenessProbe.periodSeconds | int | `10` | Defines how often to perform the ICM container probe. |
| livenessProbe.timeoutSeconds | int | `2` | Defines when the ICM container probe times out. |
| livenessProbe.failureThreshold | int | `10` | Defines the minimum consecutive failures for the ICM container probe to be considered failed after having succeeded. |
| livenessProbe.successThreshold | int | `1` | Defines the minimum consecutive successes for the ICM container probe to be considered successful after having failed. |
| readinessProbe | object | `{"failureThreshold":10,"initialDelaySeconds":30,"periodSeconds":10,"successThreshold":1,"timeoutSeconds":3}` | Learn about readiness probes at https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/. Learn about the probe's configuration settings at https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/#configure-probes. |
| readinessProbe.initialDelaySeconds | int | `30` | Defines the delay before the ICM container readiness probe is initiated. |
| readinessProbe.periodSeconds | int | `10` | Defines how often to perform the ICM container probe. |
| readinessProbe.timeoutSeconds | int | `3` | Defines when the ICM container probe times out. |
| readinessProbe.failureThreshold | int | `10` | Defines the minimum consecutive failures for the ICM container probe to be considered failed after having succeeded. |
| readinessProbe.successThreshold | int | `1` | Defines the minimum consecutive successes for the ICM container probe to be considered successful after having failed |
| existingServiceAccount | string | `""` | A custom service account that runs the ICM pod. Also, you may need to create a service account when passing Secrets to Kubernetes from an external secret management system. In such a case, the service account must have the permissions to access the external system (e.g. AWS Secrets Manager). |
| podSecurityContext.runAsUser | int | `1001` | Learn about this setting at https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-pod. |
| podSecurityContext.fsGroup | int | `1001` | Learn about this setting at https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-pod. |
| podSecurityContext.runAsNonRoot | bool | `true` | Learn about this setting at https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-pod. |
| podSecurityContext.seccompProfile | object | `{"type":"RuntimeDefault"}` | Learn about this setting at https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-seccomp-profile-for-a-container. |
| securityContext.readOnlyRootFilesystem | bool | `true` | Learn about this setting at https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-container. |
| securityContext.privileged | bool | `false` | Learn about this setting at https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-container. |
| securityContext.allowPrivilegeEscalation | bool | `false` | Learn about this setting at https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-container. |
| securityContext.runAsUser | int | `1001` | Learn about this setting at https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-the-security-context-for-a-container. |
| securityContext.capabilities | object | `{"drop":["ALL"]}` | Learn about this setting at https://kubernetes.io/docs/tasks/configure-pod-container/security-context/#set-capabilities-for-a-container. The default (recommended) configuration prohibits all Linux capabilities. |
| resources.requests.cpu | int | `2` | Specifies the number of CPUs that an ICM container requests within its Kubernetes pod. Kubernetes uses CPU requests to find a machine that best fits the container. It defines a minimum number of CPUs that the container may consume. If there is no contention for CPU, it may use as many CPUs as is available on the machine. If there is CPU contention on the machine, CPU requests provide a relative weight across all containers on the system for how much CPU time the container may use. |
| resources.requests.memory | string | `"1Gi"` | Specifies the amount of memory required for an ICM container to run. Even though each container is able to consume as much memory on the machine as possible, this parameter improves placement of pods in the cluster. Kubernetes then takes available memory into account prior to binding your pod to a machine. |
| resources.limits.memory | string | `"1Gi"` | Defines the amount of memory an ICM container is limited to use. If the container exceeds the specified memory limit, it will be terminated and potentially restarted depending on the container restart policy. |
| service.annotations | object | `{}` | Provide any additional annotations which may be required. |
| service.type | string | `"ClusterIP"` | Defines the value for the service Kubernetes object. It is recommended to keep the default value because it makes ICM accessible only from within the Kubernetes cluster. The LoadBalancer value makes ICM accessible from the Internet. This should only be used for testing purposes. [ClusterIP/LoadBalancer] |
| deployment.annotations | object | `{}` | Provides the ability to customize ICM's deployment using Kubernetes annotations. |
| podLabels | object | `{}` | Additional labels for ICM pods |
| customEnvs | object | `{}` | Allows you to specify custom environment variables for the ICM container. |

